// SPDX-License-Identifier: GPL-2.0
#include <linux/thermal.h>
#include <soc/google/gs_tmu.h>
#include "mobile-thermal.c"
